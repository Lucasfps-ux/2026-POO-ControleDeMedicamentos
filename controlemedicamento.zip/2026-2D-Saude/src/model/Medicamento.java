package model;

public class Medicamento {
    private final String nome;
    private final String horario;
    private boolean tomado;

    public Medicamento(String nome, String horario) {
        this.nome = nome;
        this.horario = horario;
        this.tomado = false;
    }

    public void marcarComoTomado() {
        this.tomado = true;
    }

    public String getNome() {
        return nome;
    }

    public String getHorario() {
        return horario;
    }

    public boolean isTomado() {
        return tomado;
    }
}