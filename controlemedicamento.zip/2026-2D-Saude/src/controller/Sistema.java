
package controller;

import java.util.ArrayList;
import model.Medicamento;

public class Sistema {
    private final ArrayList<Medicamento> lista = new ArrayList<>();

    public void adicionarMedicamento(String nome, String horario) {
        lista.add(new Medicamento(nome, horario));
    }

    public void listarMedicamentos() {
        if (lista.isEmpty()) {
            System.out.println("Nenhum medicamento cadastrado.");
            return;
        }

        for (int i = 0; i < lista.size(); i++) {
            Medicamento m = lista.get(i);
            System.out.println(i + " - " + m.getNome() +
                    " | Horário: " + m.getHorario() +
                    " | Tomado: " + m.isTomado());
        }
    }

    public void marcarComoTomado(int index) {
        if (index >= 0 && index < lista.size()) {
            lista.get(index).marcarComoTomado();
            System.out.println("Medicamento marcado como tomado!");
        } else {
            System.out.println("Índice inválido!");
        }
    }
}