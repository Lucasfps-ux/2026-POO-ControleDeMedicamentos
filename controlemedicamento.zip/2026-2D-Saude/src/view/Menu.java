package view;

import java.util.Scanner;
import controller.Sistema;

public class Menu {
    private Sistema sistema = new Sistema();
    private Scanner scanner = new Scanner(System.in);

    public void iniciar() {
        int opcao;

        do {
            System.out.println("\n===== MEDCONTROL =====");
            System.out.println("1 - Cadastrar medicamento");
            System.out.println("2 - Listar medicamentos");
            System.out.println("3 - Marcar como tomado");
            System.out.println("0 - Sair");
            System.out.print("Escolha: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    cadastrar();
                    break;
                case 2:
                    sistema.listarMedicamentos();
                    break;
                case 3:
                    marcar();
                    break;
                case 0:
                    System.out.println("Encerrando...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }

        } while (opcao != 0);
    }

    private void cadastrar() {
        System.out.print("Nome do medicamento: ");
        String nome = scanner.nextLine();

        System.out.print("Horário (ex: 08:00): ");
        String horario = scanner.nextLine();

        sistema.adicionarMedicamento(nome, horario);
        System.out.println("Medicamento cadastrado!");
    }

    private void marcar() {
        sistema.listarMedicamentos();
        System.out.print("Digite o índice do medicamento: ");
        int index = scanner.nextInt();

        sistema.marcarComoTomado(index);
    }
}